// jobs/userDataSyncJob.js - Real-time User Data Sync to Firebase
const User = require('../models/User');
const Watchlist = require('../models/Watchlist');
const Order = require('../models/Order');
const Holding = require('../models/Holding');
const Position = require('../models/Position');
const Stock = require('../models/Stock');
const UserFirebaseService = require('../services/userFirebaseService');

const userFirebase = new UserFirebaseService();
let syncInterval = null;

// =====================================================
// SYNC ALL USERS DATA
// =====================================================

async function syncAllUsersData() {
    try {
        // Get all active users
        const users = await User.find({ isActive: true }).lean();
        
        console.log(`🔄 Syncing data for ${users.length} users...`);
        
        for (const user of users) {
            await syncSingleUserData(user._id.toString());
        }
        
        console.log(`✅ Completed sync for ${users.length} users`);
        
    } catch (error) {
        console.error('User data sync error:', error.message);
    }
}

// =====================================================
// SYNC SINGLE USER DATA
// =====================================================

async function syncSingleUserData(userId) {
    try {
        // Get user profile
        const user = await User.findById(userId).lean();
        if (!user) {
            console.log(`⚠️ User ${userId} not found`);
            return;
        }
        
        // Get watchlist
        const watchlist = await Watchlist.find({ userId: userId }).lean();
        
        // Get orders (recent 50)
        const orders = await Order.find({ userId: userId })
            .sort({ createdAt: -1 })
            .limit(50)
            .lean();
        
        // Get holdings
        const holdings = await Holding.find({ userId: userId }).lean();
        
        // Update holdings with current prices
        const holdingsWithPrices = await updateHoldingsPrices(holdings);
        
        // Get positions
        const positions = await Position.find({ 
            userId: userId
        }).lean();
    
        // Update positions with current prices
        const positionsWithPrices = await updatePositionsPrices(positions);
       
        // Sync to Firebase
        await userFirebase.syncAllUserData(userId, {
            profile: user,
            watchlist: watchlist,
            orders: orders,
            holdings: holdingsWithPrices,
            positions: positionsWithPrices
        });
        
    } catch (error) {
        console.error(`Sync error for user ${userId}:`, error.message);
    }
}

// =====================================================
// UPDATE HOLDINGS WITH CURRENT PRICES
// =====================================================

async function updateHoldingsPrices(holdings) {
    try {
        if (!holdings || holdings.length === 0) return [];
        
        const symbols = holdings.map(h => h.stockSymbol);
        const stocks = await Stock.find({ 
            symbol: { $in: symbols } 
        }).lean();
        
        const priceMap = {};
        stocks.forEach(stock => {
            priceMap[stock.symbol] = stock.currentPrice;
        });
        
        return holdings.map(holding => ({
            ...holding,
            currentPrice: priceMap[holding.stockSymbol] || holding.averagePrice || 0
        }));
        
    } catch (error) {
        console.error('Update holdings prices error:', error.message);
        return holdings;
    }
}

// =====================================================
// UPDATE POSITIONS WITH CURRENT PRICES
// =====================================================

async function updatePositionsPrices(positions) {
    try {
        if (!positions || positions.length === 0) return [];
 
        const symbols = positions.map(p => p.symbol);
        
        const stocks = await Stock.find({ 
            symbol: { $in: symbols } 
        }).lean();
        
        const priceMap = {};
        stocks.forEach(stock => {
            priceMap[stock.symbol] = stock.currentPrice;
        });
        
        return positions.map(position => ({
            ...position,
            currentPrice: priceMap[position.symbol] || position.entryPrice || 0
        }));
        
    } catch (error) {
        console.error('Update positions prices error:', error.message);
        return positions;
    }
}

// =====================================================
// START USER DATA SYNC JOB
// =====================================================

function startUserDataSync(intervalSeconds = 5) {
    if (syncInterval) {
        clearInterval(syncInterval);
    }
    
    console.log(`🔥 Starting user data Firebase sync (every ${intervalSeconds} seconds)...`);
    
    // Initial sync
    syncAllUsersData();
    
    // Periodic sync
    syncInterval = setInterval(() => {
        syncAllUsersData();
    }, intervalSeconds * 1000);
    
    console.log(`✅ User data sync job started`);
}

// =====================================================
// STOP USER DATA SYNC JOB
// =====================================================

function stopUserDataSync() {
    if (syncInterval) {
        clearInterval(syncInterval);
        syncInterval = null;
        console.log('⏹️ User data sync job stopped');
    }
}

// =====================================================
// SYNC SPECIFIC USER (On-demand)
// =====================================================

async function syncUser(userId) {
    try {
        await syncSingleUserData(userId);
        console.log(`✅ User ${userId} synced to Firebase`);
        return true;
    } catch (error) {
        console.error(`Failed to sync user ${userId}:`, error.message);
        return false;
    }
}

// =====================================================
// EXPORTS
// =====================================================

module.exports = {
    startUserDataSync,
    stopUserDataSync,
    syncUser,
    syncAllUsersData,
    syncSingleUserData
};

// =====================================================
// USAGE IN server.js
// =====================================================

/*
const { startUserDataSync } = require('./jobs/userDataSyncJob');

// Start MongoDB connection
mongoose.connect(...)
  .then(() => {
    console.log('✅ Connected to MongoDB');
    
    // Start user data sync (every 5 seconds)
    startUserDataSync(5);
    
    // Also start stock/index sync
    const { startFirebaseUpdates } = require('./jobs/firebaseUpdateJob');
    startFirebaseUpdates();
  });
*/
