// models/User.js - Updated with Margin System
const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');

const userSchema = new mongoose.Schema({
  username: {
    type: String,
    required: true,
    unique: true,
    trim: true,
    lowercase: true
  },
  password: {
    type: String,
    required: true,
    minlength: 6
  },
  email: {
    type: String,
    required: true,
    unique: true,
    lowercase: true
  },
  fullName: {
    type: String,
    required: true
  },
  clientId: {
    type: String,
    unique: true
  },
  
  // =====================================================
  // BALANCE & MARGIN FIELDS
  // =====================================================
  
  // Cash balance (actual money)
  availableBalance: {
    type: Number,
    default: 0
  },
  
  // Margin given by admin (extra buying power)
  marginAllowed: {
    type: Number,
    default: 0,
    min: 0
  },
  
  // Margin multiplier (e.g., 5x means 5 times the balance)
  marginMultiplier: {
    type: Number,
    default: 1,
    min: 1,
    max: 10
  },
  
  // Currently used margin
  usedMargin: {
    type: Number,
    default: 0
  },
  
  // Total P&L (profit/loss)
  totalPnL: {
    type: Number,
    default: 0
  },
  
  // Portfolio value
  portfolioValue: {
    type: Number,
    default: 0
  },
  
  // Account status
  isActive: {
    type: Boolean,
    default: true
  },
  
  // Margin enabled/disabled by admin
  marginEnabled: {
    type: Boolean,
    default: true
  },
  
  // Risk settings
  maxLossPerDay: {
    type: Number,
    default: 0 // 0 means no limit
  },
  
  todayPnL: {
    type: Number,
    default: 0
  },
  
  lastPnLReset: {
    type: Date,
    default: Date.now
  }
  
}, {
  timestamps: true
});

// =====================================================
// VIRTUAL FIELDS (Calculated)
// =====================================================

// Total margin available = balance + margin allowed
userSchema.virtual('totalMargin').get(function() {
  if (!this.marginEnabled) {
    return this.availableBalance;
  }
  
  // If multiplier is set, use it
  if (this.marginMultiplier > 1) {
    return this.availableBalance * this.marginMultiplier;
  }
  
  // Otherwise use fixed margin
  return this.availableBalance + this.marginAllowed;
});

// Available margin (not used)
userSchema.virtual('availableMargin').get(function() {
  const total = this.totalMargin;
  return Math.max(0, total - this.usedMargin);
});

// Margin utilization percentage
userSchema.virtual('marginUtilization').get(function() {
  const total = this.totalMargin;
  if (total === 0) return 0;
  return (this.usedMargin / total) * 100;
});

// =====================================================
// METHODS
// =====================================================

// Hash password before saving
userSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
  next();
});

// Compare password
userSchema.methods.comparePassword = async function(candidatePassword) {
  return await bcrypt.compare(candidatePassword, this.password);
};

// Generate Client ID
userSchema.pre('save', function(next) {
  if (!this.clientId) {
    this.clientId = 'CL' + Date.now() + Math.floor(Math.random() * 1000);
  }
  next();
});

// Check if user has enough margin
userSchema.methods.hasEnoughMargin = function(amount) {
  return this.availableMargin >= amount;
};

// Use margin (when placing order)
userSchema.methods.useMargin = async function(amount) {
  if (!this.hasEnoughMargin(amount)) {
    throw new Error('Insufficient margin');
  }
  
  this.usedMargin += amount;
  await this.save();
  return true;
};

// Release margin (when closing position)
userSchema.methods.releaseMargin = async function(amount) {
  this.usedMargin = Math.max(0, this.usedMargin - amount);
  await this.save();
  return true;
};

// Reset daily P&L (run at midnight)
userSchema.methods.resetDailyPnL = async function() {
  this.todayPnL = 0;
  this.lastPnLReset = new Date();
  await this.save();
};

// Ensure virtuals are included in JSON
userSchema.set('toJSON', { virtuals: true });
userSchema.set('toObject', { virtuals: true });

module.exports = mongoose.model('User', userSchema);
